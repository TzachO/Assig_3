package assig3_2;

import assig3_2.MySemaphore;

public class HeavyWorker {

	private final MySemaphore sem1 = new MySemaphore(3);
	private final MySemaphore sem2 = new MySemaphore(1);
	private boolean workADone = false;

	public void section1() {
		System.out.println(Thread.currentThread().getName() + " is in section1");
		try {
			/* sleep to simulate some work... */
			Thread.sleep(500);
		} catch (InterruptedException e) {
		}
		System.out.println(Thread.currentThread().getName() + " leaving section1");
	}

	public void section2() {
		MySemaphore sem = new MySemaphore(1);
		sem.down();

		System.out.println(Thread.currentThread().getName() + " is in section2");
		try {
			/* sleep to simulate some work... */
			Thread.sleep(500);
		} catch (InterruptedException e) {
		}
		System.out.println(Thread.currentThread().getName() + " leaving section2");

		sem.up();
	}

	public void workA() {
		System.out.println(Thread.currentThread().getName() + " doing workA");

		sem1.down();
		section1();
		sem1.up();

		sem2.down();
		section2();
		sem2.up();

		workADone = true;
	}

	public void workB() {
		while (!workADone) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}

		/* this will be printed only after workA() done at least once */
		System.out.println(Thread.currentThread().getName() + " doing workB");
	}
}

