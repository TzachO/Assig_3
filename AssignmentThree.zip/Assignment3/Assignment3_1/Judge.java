//Shon Malka 205519317 + Tzach Ofir 208062943
package Assignment3_1;

import static java.lang.Thread.*;

public class Judge extends Gamer implements Runnable{
    public void checkInterruptStatus() throws InterruptedException {
        while (!interrupted()){
            makeCoinAvail(false);
            sleep(1000);
            makeCoinAvail(true);
            sleep(500);
        }
    }

    @Override
    public void run() {
        try {
            checkInterruptStatus();
        } catch (InterruptedException ignored) {
        }
    }
}
