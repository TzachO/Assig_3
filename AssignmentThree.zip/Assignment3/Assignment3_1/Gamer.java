//Shon Malka 205519317 + Tzach Ofir 208062943
package Assignment3_1;

import static java.lang.Thread.*;

public class Gamer extends GamePlay implements Runnable{
    private int goodFlipsCounter;
    private GamePlay p=new GamePlay();

    public void play(){
        for(int i=0;i<10;i++){
            if (!interrupted()){
                try {
                    if(this.p.flipCoin())
                        this.goodFlipsCounter++;
                    sleep(1000);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public int getScore(){
        return this.goodFlipsCounter;
    }

    public void run() {
        play();
        currentThread().interrupt();
    }
}
