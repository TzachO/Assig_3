//Shon Malka 205519317 + Tzach Ofir 208062943
package Assignment3_1;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class GamePlay {
    private boolean coin_available;
    private int rounds_counter;

    public GamePlay(){
        this.coin_available=true;
        rounds_counter=0;
    }
    private Lock lock = new ReentrantLock();
    public synchronized void makeCoinAvail(boolean val){
        lock.lock();
        this.coin_available= val;
        lock.unlock();
        if (val)
            notifyAll();
    }
    public boolean flipCoin() throws InterruptedException {
        boolean coinStatus;
        if (!isCoin_available()) {
            System.out.println(Thread.currentThread().getName()+" is waiting for coin.");
            this.wait();
        }
        makeCoinAvail(false);
        lock.lock();
        System.out.println(Thread.currentThread().getName()+" is flipping the coin.");
        pushRounds_counter();
        coinStatus=headsORtails();
        lock.unlock();
        makeCoinAvail(true);
        return coinStatus;
    }

    public int getRounds_counter() {
        return rounds_counter;
    }

    public synchronized boolean isCoin_available() {
        return this.coin_available;
    }

    public void pushRounds_counter() {
        rounds_counter = rounds_counter++;
    }
    public boolean headsORtails(){
        return Math.random() > 0.5;
    }
}
