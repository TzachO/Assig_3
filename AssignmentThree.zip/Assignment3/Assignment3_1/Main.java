//Shon Malka 205519317 + Tzach Ofir 208062943
package Assignment3_1;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        GamePlay round = new GamePlay();
        Gamer p0 = new Gamer();
        Gamer p1 = new Gamer();
        Thread t0 = new Thread(p0);
        Thread t1 = new Thread(p1);
        Judge judy = new Judge();
        Thread tj = new Thread(judy);
        tj.start();
        t0.start();
        t1.start();
        while (!tj.isInterrupted()) {
            if (t0.isInterrupted() && t1.isInterrupted()) {
                tj.interrupt();
            }
        }
            if (p0.getScore() > p1.getScore())
                System.out.println("Winner is Thread-0! with " + p0.getScore() + " points!");
            if (p0.getScore() < p1.getScore())
                System.out.println("Winner is Thread-1! with " + p1.getScore() + " points!");
            if (p1.getScore()== p0.getScore())
                System.out.println("No winner!, it's a tie!");
    }
}